<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="\testlaravel\app\css\animate.css" >
    <link rel="stylesheet" href="\testlaravel\app\css\csstest.css">
    <link rel="stylesheet" href="\testlaravel\app\untitled_folder\dist\vendor\font-awesome\css\fontawesome-all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Kanit" rel="stylesheet">
    <link rel="stylesheet" href="\testlaravel\appt\css\owl.carousel.css">
    <link rel="stylesheet" href="\testlaravel\app\css\owl.theme.default.css">
       <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="\testlaravel\app\js\jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    <script src="\testlaravel\app\js\jquery.min.js"></script>
    <script src="\testlaravel\app\js\owl.carousel.js"></script>
   

    





    <title> TEST</title>
  </head>
  <body class="body" >
  <section class="menu"> <!--menu-->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light" id="mainNav">
      <button class="navbar-toggler js-scroll-trigger" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <a class="navbar-brand">
          <img src="\testlaravel\app\img\insert-coin.png" width="50px">
      </a>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav nav-pills nav-fill mr-auto">
            <li class="nav-item active">
              <a class="nav-link  btn-outline-warning" href="#">หน้าแรก</a>
            </li>
              <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="#box1">ขนาด</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="#box2">ราคา</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="#box4">ติดต่อ</a>
              </li>
          </ul>
          
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-warning my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
          <a class="nav-link btn-login" href="#">
          <a href="<?php echo e(route('login')); ?>"><button type="button" class="btn btn-outline-dark" data-toggle="modal">เข้าสู้ระบบ</button></a>
          </a>
        </form>
      </div>  
      </nav>




      <section class="menu">
          <style>
              section.menu .bg-light.navbar-scroll{
                  background-color: rgb(255, 156, 110) !important;
                  -webkit-transition: all 0.5s;
                  -moz-transition: all 0.5s;
                  transition: all 0.5s;
              }
          </style>

      </section>
</section>   
     <!--header -->
<section class="pb-3 mt-5">


    </section>
     <!-- หน้าหลัก -->
<div class="container">
<section class="header-img pb-3">
        <div class="col-md-sm">
        
        <br><br><!--<img src="\testlaravel\app\img\hearder.jpg "width="50%" class="animated rubberBand">-->
        
        </div>
    </section>
          

     <!-- หน้าหลัก -->
<div class="container">                    
<section class="GALLERY" id="box1">
          <div class="container">
                 <h2 class="animated jello text-center pt-5">SIZE</h2>
                 <hr style="width:210px">   
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home">
                        <div class="row">
                            <div class="col col-xs-12 mt-3"><a href="<?php echo e(route('login')); ?>"><img class="d-block w-100" src="\testlaravel\app\img\coin.png"></a>
                            <h5 class="mt-2">S</h5>
                            <p>ชั่วโมงละ 50 บาท</p>
                          </div>
                            <div class="col col-xs-12 mt-3"><a href="<?php echo e(route('login')); ?>"><img class="d-block w-100" src="\testlaravel\app\img\coin.png"></a>
                            <h5 class="mt-2">M</h5>
                            <p>ชั่วโมงละ 100 บาท</p>
                          </div>
                            <div class="col col-xs-12 mt-3"><a href="<?php echo e(route('login')); ?>"><img class="d-block w-100" src="\testlaravel\app\img\coin.png"></a>
                            <h5 class="mt-2">L</h5>
                            <p>ชั่วโมงละ 200 บาท</p>
                          </div>
                        </div>  
                    </div>
                  </div>
                </div>                
</section>      
 <section class="Products" id="box2" >
   <table class="table mb-5 mt-5">
      <h2 class="animated lightSpeedIn text-center pt-5" id="Product">Promotion<p class="animated infinite fadeOut delay-6s" >NOW</p></h2> 
  <thead>
    <tr>
      <th scope="col">S</th>
      <th scope="col">M</th>
      <th scope="col">L</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"><p>ชั่วโมงแรก 50 บาท ชั่วโมงถัดไป 25 บาท</p></a></th>
      <th><p>ชั่วโมงแรก 50 บาท ชั่วโมงถัดไป 25 บาท</p></th>
      <th><p>ชั่วโมงแรก 50 บาท ชั่วโมงถัดไป 25 บาท</p></th>
    </tr>
  </tbody>
</table>
      </div>
 </section>

<section class="other">
    <div class="container ">
           <div class="text-center pt-3 pb-3"><button type="button" class="btn btn-outline-dark">ดูทั้งหมด...</button>
           </div>
           
</section>

  <section class="contuct" id="box4">
      <div class="container">
             <h1 class="animated rollIn pt-5">ติดต่อ</h1>
             <hr style="width:300px">
             <h3 class="text-center pb-3">I GEAR GEEK:Coin</h3>  

              <div class="row">
                <div class="col">
                    <form>
                      <div class="text-left">
                        <div class="form-group">
                          <label for="exampleFormControlInput1">ชื่อ-นามสกุล*: </label>
                          <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="ชื่อ-นามสกุล">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">E-mail*: </label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="E-mail">
                        </div>
                          <div class="form-group">
                              <label for="exampleFormControlInput1">หัวข้อ*: </label>
                              <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="หัวข้อ">
                          </div>
                            <label for="exampleFormControlTextarea1">ข้อความ*: </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                           <button type="button" class="btn btn-warning mt-3">ส่งข้อความ</button>
                      </div>
                </div>

   </section>

      <section class="footer">        <!-- footer -->
        <div class="col-gl">
        </div>
      </section>













      <!--<section class="About mb-5 mt-5">
          <div class="container profile">
              <div class="row">
                  <div class="col-lg-6">
                      <img class="d-block w-100" src="\test\test\untitled_folder\img\pic2.png">
                  </div>
                  <div class="col-lg-6">
                      <h3 class="animated bounceInRight">ประวัติฟาร์ม Farm History</h3>
                      <p><font color="#9c9c94">
                          ปี 2526 นายสายัณห์ เอี่ยมประชา (ซึ่งในขณะนั้นรับราชการเป็นเกษตรจังหวัด น่าน) ได้เชิญวิทยากรจากกรมส่งเสริมการเกษตร มาอบรมวิธีการเลี้ยงผึ้งที่ถูกต้อง ให้แก่เกษตรกรในจังหวัดทำให้เกิดความสนใจ และ ได้ทดลองเลี้ยงผึ้งจำนวน 8 รัง เพื่อให้เป็นตัวอย่างให้แก่เกษตรกร
                      </font></p>
                      <p><font color="#9c9c94">
                     จากจุดเริ่มต้นนั้นได้มีพัฒนาอย่างมาต่อเนื่องจนก่อตั้งขึ้นเป็น "ฟาร์มผึ้งสายัณห์ " และ ได้ขยายกิจการเรื่อยมามีการพัฒนากรรมวิธีการผลิตตามหลักการวิชาการ
                           อย่างถูกต้องเพื่อให้ได้น้ำผึ้งที่มีคุณภาพ ฟาร์มผึ้งสายัณห์ เป็นผู้ริเริ่มจัดส่งน้ำผึ้งให้แก่ โครงการส่วนพระองค์สวนจิตรลดา 
                           ขณะนี้ฟาร์มผึ้งสายัณห์มีผึ้งอยู่ใน ความดูแลประมาณ 1,000 รังและยังมีความตั้งใจที่จะไม่ขยายจำนวนรัง ให้เพิ่ม 
                           จำนวนมากไปกว่านี้ เนื่องจากต้องการเน้นคุณภาพ เป็นสิ่งสำคัญ และเพื่อให้เป็นจุดเด่นของ"ฟาร์มผึ้งสายัณห์"
                       </font></p>
                       <p><font color="#9c9c94">ปี 2540 ฟาร์มผึ้งสายัณห์ ได้ริเริ่มผลิต รวงผึ้ง ( Honey Comb ) 
                         ขึ้นเป็นรายแรกของประเทศ ในรูปของ Bee-o-Pac และได้พัฒนาต่อมาเป็น 
                         Honey Comb in Frame และ Honey comb in Box เป็นรายแรกของประเทศ ปัจจุปัน 
                         ฟาร์มผึ้งสายัณห์คือผู้ผลิตและจำหน่าย รวงผึ้ง ( Honey Comb ) รายใหญ่ที่สุดของประเทศ 
                       </font></p>
                  </div>
              </div>
          </div>
        </div>
      </section>-->
      <!--model-->

  <!--<section class="contuct" id="box4">
      <div class="container">
                <div class="col-lg-4">
                <div class="text-left " id="map">
                  <p>ที่ตั้ง: 30/283 หมู่ 6 แขวนทุ่งสองห้อง เขตหลักสี่ กรุงเทพฯ 10210</p>
                  <p>โทรศัพท์: 0-2954-5089, 02954-7488</p>
                  <p>แฟกซ์:0-29547439 </p>
                  <p>มือถือ: 081-9205788</p>
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d69569.10863440002!2d100.54784581876613!3d13.857674474621483!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb75498e8c6aa65b9!2z4Lia4Lij4Li04Lip4Lix4LiXIOC4n-C4suC4o-C5jOC4oeC4nOC4tuC5ieC4h-C4quC4suC4ouC4seC4k-C4q-C5jCDguIjguLPguIHguLHguJQ!5e0!3m2!1sth!2sth!4v1520578324725" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>	
                </div>
                </div>
              </div>

   </section>-->

      <section class="footer">        <!-- footer -->
        <div class="col-gl">
            <img  class="mt-3" width="50" height="50"  src="\test\test\untitled_folder\img\footer.png">
            <label3> All right </label><br>
              
        </div>
      </section>

  

            
         

 <!-- Plugin JavaScript -->
 
  </body>
</html>
<?php /* C:\xampp\htdocs\testlaravel\app\resources\views/index.blade.php */ ?>