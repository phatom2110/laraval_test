@extends('layouts.app')
@section('content')
<div class="container">
<div class="alert alert-primary" role="alert">
  locker size = S
</div>
<form class="form-inline" method="post" action="{{route('Product.store')}}">
@csrf
<div class="form-group col-md-12 mr-2">
<input type="hidden" name="size" value="{{route('Product.store')}}">
      <label for="inputState" style="margin:5px">Minutes</label>
      
        <select id="inputState" class="form-control" name="minutes">
         <option selected>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
            <option>13</option>
            <option>14</option>
            <option>15</option>
            <option>16</option>
            <option>17</option>
            <option>18</option>
            <option>19</option>
            <option>20</option>
            <option>21</option>
            <option>22</option>
            <option>23</option>
            <option>24</option>
        
      </select>
      <label style="margin:5px">Hr</label>
      <button type="submit" class="btn btn-primary "style="margin:5px">บันทึก</button>
</button>
      </form>
</div>
</div>
</div>





@endsection



